namespace VeterinariaSanMiguel.Models;

public class VeterinaryAppointment
{
    //Esto es la cita
}