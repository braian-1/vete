namespace VeterinariaSanMiguel.Models;

public class Veterinary
{
    
}