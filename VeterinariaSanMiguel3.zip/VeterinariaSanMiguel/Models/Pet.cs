namespace VeterinariaSanMiguel.Models;

public class Pet
{
    
}