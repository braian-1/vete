namespace VeterinariaSanMiguel.Services;

public class VeterinaryService
{
    //aqui los cruds
}