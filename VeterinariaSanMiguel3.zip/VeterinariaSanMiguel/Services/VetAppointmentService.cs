namespace VeterinariaSanMiguel.Services;

public class VetAppointmentService
{
    //aqui los cruds
}