namespace VeterinariaSanMiguel.Services;

public class PetService
{
    //aqui los cruds
}